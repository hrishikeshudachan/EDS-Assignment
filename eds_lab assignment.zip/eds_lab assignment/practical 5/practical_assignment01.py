# 5.1.1 Stacked plot 
import matplotlib.pyplot as plt
import pandas as pd

# Data for Months and Temperature for three cities
data = {
    'Month': ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    'City_A_Temperature': [5, 7, 10, 13, 17, 20, 22, 21, 18, 12, 8, 6],
    'City_B_Temperature': [2, 3, 5, 6, 10, 14, 16, 17, 12, 9, 5, 3],
    'City_C_Temperature': [3, 4, 6, 8, 9, 12, 15, 14, 10, 7, 4, 2]
}

# Write your code...
df = pd.DataFrame(data)

plt.figure()
plt.stackplot(df['Month'], df['City_A_Temperature'], df['City_B_Temperature'], df['City_C_Temperature'],
labels = ['City A', 'City B', 'City C'], alpha=1)

plt.xlabel("Month")
plt.ylabel("Temperature")
plt.title("Temperature Variation")

plt.show()

